BiocGenerics:::testPackage("SNPRelate")
